employees = [ 
["EMP001","Amit Patel",25000,"IT"], 
["EMP002","Priya Shah",30000,"HR"], 
["EMP003","Rohit Kumar",-5000,"IT"], 
["EMP004","Neha Joshi",45000,"Finance"], 
["EMP005","",28000,"HR"], 
["EMP006","Raj Mehta",None,"IT"], 
["EMP007","Karan Singh",35000,"Sales"], 
["EMP008","Pooja Patel",0,"Marketing"], 
["EMP009","Amit Patel",25000,"IT"], 
["EMP010","Meena Desai",50000,""], 
 
["EMP011","Riya Sharma",32000,"HR"], 
["EMP012","Vikas Patel",27000,"IT"], 
["EMP013","Sneha Shah",42000,"Finance"], 
["EMP014","Nirav Mehta",39000,"Sales"], 
["EMP015","Anjali Patel",31000,"Marketing"], 
["EMP016","Dhruv Shah",29000,"IT"], 
["EMP017","Krunal Patel",34000,"HR"], 
["EMP018","Jinal Shah",36000,"Finance"], 
["EMP019","Parth Mehta",41000,"Sales"], 
["EMP020","Nidhi Patel",38000,"Marketing"], 
 
["EMP021","Harsh Shah",26000,"IT"], 
["EMP022","Bhavik Patel",27500,"HR"], 
["EMP023","Komal Shah",33000,"Finance"], 
["EMP024","Yash Mehta",37000,"Sales"], 
["EMP025","Mansi Patel",35000,"Marketing"], 
["EMP026","Dev Shah",45000,"IT"],
["EMP027","Isha Patel",48000,"HR"], 
["EMP028","Jay Mehta",29000,"Finance"], 
["EMP029","Kajal Shah",31000,"Sales"], 
["EMP030","Manav Patel",34000,"Marketing"], 

["EMP031","Aarav Shah",30000,"IT"], 
["EMP032","Diya Patel",32000,"HR"], 
["EMP033","Vivaan Mehta",36000,"Finance"], 
["EMP034","Kiara Shah",38000,"Sales"], 
["EMP035","Aditya Patel",42000,"Marketing"], 
["EMP036","Riddhi Shah",27000,"IT"], 
["EMP037","Tushar Mehta",46000,"HR"], 
["EMP038","Pallavi Patel",39000,"Finance"], 
["EMP039","Sagar Shah",35000,"Sales"], 
["EMP040","Hetal Mehta",31000,"Marketing"], 

["EMP041","Amit Patel",25000,"IT"], 
["EMP042","Priya Shah",30000,"HR"], 
["EMP043","",41000,"Finance"], 
["EMP044","Raj Mehta",None,"Sales"], 
["EMP045","Neha Joshi",-10000,"Marketing"], 
["EMP046","Harsh Patel",36000,"IT"], 
["EMP047","Naina Shah",34000,"HR"], 
["EMP048","Vivek Mehta",43000,"Finance"], 
["EMP049","Krisha Patel",39000,"Sales"], 
["EMP050","Devanshi Shah",28000,""], 

["EMP051","Mihir Patel",31000,"IT"], 
["EMP052","Ruchi Shah",33000,"HR"], 
["EMP053","Ankit Mehta",37000,"Finance"], 
["EMP054","Bhumi Patel",40000,"Sales"], 
["EMP055","Chirag Shah",45000,"Marketing"], 
["EMP056","Dhwani Mehta",47000,"IT"], 
["EMP057","Esha Patel",29000,"HR"], 
["EMP058","Falgun Shah",31000,"Finance"], 
["EMP059","Gaurav Mehta",35000,"Sales"], 
["EMP060","Hiral Patel",38000,"Marketing"], 

["EMP061","Ishan Shah",26000,"IT"], 
["EMP062","Janki Patel",28000,"HR"], 
["EMP063","Ketan Mehta",34000,"Finance"], 
["EMP064","Lina Shah",36000,"Sales"], 
["EMP065","Milan Patel",39000,"Marketing"],
["EMP066","Nilesh Shah",42000,"IT"], 
["EMP067","Ojas Mehta",44000,"HR"], 
["EMP068","Pinal Patel",46000,"Finance"], 
["EMP069","Rakesh Shah",30000,"Sales"], 
["EMP070","Sonal Mehta",32000,"Marketing"], 

["EMP071","Tanvi Patel",35000,"IT"], 
["EMP072","Umesh Shah",37000,"HR"], 
["EMP073","Vaibhav Mehta",41000,"Finance"], 
["EMP074","Yamini Patel",43000,"Sales"], 
["EMP075","Zarna Shah",48000,"Marketing"], 
["EMP076","Aakash Mehta",29000,"IT"], 
["EMP077","Bhavna Patel",31000,"HR"], 
["EMP078","Chetan Shah",34000,"Finance"], 
["EMP079","Deepa Mehta",36000,"Sales"], 
["EMP080","Eshan Patel",40000,"Marketing"], 

["EMP081","Farhan Shah",45000,"IT"], 
["EMP082","Geeta Mehta",47000,"HR"], 
["EMP083","Hemal Patel",28000,"Finance"], 
["EMP084","Ila Shah",30000,"Sales"], 
["EMP085","Jigar Mehta",33000,"Marketing"], 
["EMP086","Kush Patel",35000,"IT"], 
["EMP087","Lavina Shah",38000,"HR"], 
["EMP088","Mitesh Mehta",42000,"Finance"], 
["EMP089","Nisha Patel",44000,"Sales"], 
["EMP090","Om Shah",46000,"Marketing"], 

["EMP091","Parul Mehta",27000,"IT"], 
["EMP092","Qadir Patel",29000,"HR"], 
["EMP093","Rina Shah",32000,"Finance"], 
["EMP094","Smit Mehta",35000,"Sales"], 
["EMP095","Tina Patel",39000,"Marketing"], 
["EMP096","Urvashi Shah",41000,"IT"], 
["EMP097","Viral Mehta",45000,"HR"], 
["EMP098","Waseem Patel",47000,"Finance"], 
["EMP099","Yogesh Shah",50000,"Sales"], 
["EMP100","Zeeshan Mehta",52000,"Marketing"], 

["EMP101","Amit Patel",25000,"IT"], 
["EMP102","",None,"HR"], 
["EMP103","Raj Mehta",-7000,"Finance"], 
["EMP104","Pooja Patel",0,"Marketing"], 
["EMP105","Sneha Shah",42000,"Finance"] 
]




# Part A: List Operations 


# Q1. 
# Find the total number of employee records.

print("total number of employee records:-",len(employees))


# Q2. 
# Add a new employee record.

employees.append(["EMP011", "Riya Sharma", 32000, "HR"])
print("insert data:-",employees)


# Q3. 
# Remove employee EMP008 from the list.

employees.remove(["EMP008","Pooja Patel",0,"Marketing"])
print(employees)



# Q4. 
# Display all employee names only.

for data in employees:
    print(data[1])


# Q5. 
# Find employees whose salary is greater than ₹30,000.

# for data in employees:
   
    salary = data[2]
    if salary is not None and salary > 30000:
          print(data[1],"-",salary)
          



# Part B: Data Cleaning Using List 
# Q6. 
# Find records having blank employee names.

print("blank employee names:-")
for i in employees:
     name = i[1]
     if name == "":
          print(i[0])


# Q7. 
# Find records having blank department names

print("blank department:-")
for i in employees:
     dipartment = i[3]
     if dipartment == "":
          print(i[0])


# Q8. 
# Find records having NULL salary values.

print("NULL salary values:-")
for i in employees:
     dipartment = i[2]
     if dipartment == None:
          print(i[0])


# Q9. 
# Find records having negative salary values.


print("Negative salary values:-")
for i in employees:
     salary = i[2]
     if salary is not None and salary < 0:
          print(i[0])



# Q10. 
# Replace negative salary with 0.

print("replace salary values:-")
for i in employees:
     salary = i[2]
     if salary is not None and salary < 0:
        i[2] = 0
print(employees)


# Q11. 
# Replace NULL salary with average salary of valid employees.

total = 0
count = 0

# Valid salary ka total aur count nikalo
for i in employees:
    salary = i[2]

    if salary is not None and salary >= 0:
        total += salary
        count += 1

average = total / count

# NULL salary ko average se replace karo
for i in employees:
    if i[2] is None:
        i[2] = average

print(employees)



# Q12. 
# Remove records having blank employee names.


for i in employees:
    name = i[1]
    if name == "":
         employees.remove(i)

print(employees)         




# Part C: Tuple Operations 
# Convert employee records into tuples. 
# Example: 
# ("EMP001", "Amit Patel", 25000, "IT") 



tpl1 = employees
print("List =",tpl1,"\n")

l1 = tuple(tpl1)
print("change Tuple =",l1)



# Q14. 
# Display Employee ID and Name using tuple indexing.


tpl1 = employees
# print("List =",tpl1,"\n")

l1 = tuple(tpl1)
print("Tuple =",l1)


for i in l1:
    print("id:-",i[0],"name:-",i[1])


# Q15. 
# Count total tuple records.

tpl1 = employees
l1 = tuple(tpl1)
print("Tuple =",l1)


# print("total tuple record:-",len(l1))

# Q.16
# Find highest salary employee using tuples.

tpl1 = employees
l1 = tuple(tpl1)
print("Tuple =",l1)

max = l1[0]

for i in l1:
    
    if i[2] is not None and i[2] > max[2]:
        max = i
print("highest salary employee=",max)



# Q17. 
# Find lowest salary employee using tuples.


tpl1 = employees
l1 = tuple(tpl1)
print("Tuple =",l1)

min = l1[0]

for i in l1:
    
    if i[2] is not None and i[2] < min[2]:
        min = i
print("lowest salary employee=",min)



# Part D: Set Operations 
# Q18. 
# Create a set of all departments.


my_set = {emp[3] for emp in employees}
print(my_set)


# Q19. 
# Display unique department names. 

my_set = {emp[3] for emp in employees}
print(my_set)

# Q20. 
# Count total unique departments.

my_set = {emp[3] for emp in employees}
print(my_set)
print("count total department:-",len(my_set))


# Q21. 
# Check whether "Finance" department exists or not.


if "Finance" in my_set:
    print("Exist")
else:
    print("Not Exist")
    


# Q22. 
# Add a new department "Administration". 


my_set.add("Administration")
print("Add new Department:-",my_set)



# Q23. 
# Remove "Marketing" department.

my_set.remove("Marketing")
print("Remove department:-",my_set)




# Part E: Duplicate Data Cleaning Using Set 
# Q24. 
# Identify duplicate employee names. 


seen = set()
duplicate = set()

for i in employees:
    name = i[1]
    if name in seen:
        duplicate.add(name)
    else:
        seen.add(name)
print("duplicate:-",duplicate)   




# Q26. 
# Count unique employees.


print(len(seen))




# Q27. 
# Find duplicate records. 
# Expected Duplicate: 
# "Amit Patel"


NameSet = set()
duplicates = []

for emp in employees:
    if emp[1] in NameSet:
        duplicates.append(emp)
    else:
        NameSet.add(emp[1])

print("Duplicate Records:", duplicates)
print("Expected Duplicate:", duplicates[0][1])



# Part F: Data Analysis 
# Q28. 
# Calculate total salary expenditure.


my_set = {emp[2] for emp in employees}
print(my_set)


total = 0
for i in my_set:
    if i is not None and i > 0:
        total+=i
print("total salary:-",total)



# Q29. 
# Calculate average salary.



total = 0
count = 0


for i in my_set:
    

    if i is not None and i >= 0:
        total += i
        count += 1

average = total / count

print("avrage salary:-",average)




# Q30. 
# Find maximum salary.



set1 = {x for x in my_set if x is not None}
print("max value :-",max(set1))

# Q31. 
# Find minimum salary.

set1 = {x for x in my_set if x is not None}
print("minimum value :-",min(set1))



# Q32. 
# Count employees department-wise. 
# Example Output:



it = 0
fc = 0
market = 0
hr= 0
sales = 0

for data in employees:
    print(data[3])
    if data[3] == "IT":
        it += 1
    if data[3]  == "Marketing":
        market +=1
    if data[3] == "Finance":
        fc += 1
    if data[3] == "HR":
        hr += 1
    if data[3] == "Sales":
        sales += 1


print("it:-",it)
print("Marketing:-",market)
print("Finance:-",fc)
print("HR:-",hr)
print("sales:-",sales)




# Part G: Mini Project 
# Employee Data Cleaning Report
        
# Remove duplicate employee names


my_set = {emp[1] for emp in employees}
print(my_set)

# Remove blank names 

for i in employees:
    name = i[1]
    if name == "":
         employees.remove(i)

print(employees)  


# Replace NULL salary with average salary 

total = 0
count = 0


for i in employees:
    salary = i[2]

    if salary is not None and salary >= 0:
        total += salary
        count += 1

average = total / count


for i in employees:
    if i[2] is None:
        i[2] = average

print("replace null salary to 0:-",employees)



#  Replace negative salary with 0 

print("replace salary values:-")
for i in employees:
     salary = i[2]
     if salary is not None and salary < 0:
        i[2] = 0
print(employees)



#  Replace blank department with "Unknown" 
print("replace salary values:-")
for i in employees:
     department = i[3]
     if department is not None and department == "":
        i[2] = "Unknown" 
print(employees)




# ✔ Display: 
# • Total Employees  
# • Total Departments  
# • Total Salary  
# • Average Salary  
# • Highest Salary Employee  
# • Lowest Salary Employee 

# • Total Employees  
my_set = {emp[1] for emp in employees}
print("total nmber of employee:-",len(my_set))


# • Total Departments  
my_set = {emp[3] for emp in employees}
print("total nmber of department:-",len(my_set))


# • Total Salary  

my_set = {emp[2] for emp in employees}
print(my_set)

total = 0
for i in my_set:
    if i is not None and i > 0:
       total+=i
print("total salary:-",total)


# • Average Salary  
total = 0
count = 0


for i in employees:
    salary = i[2]

    if salary is not None and salary >= 0:
        total += salary
        count += 1

average = total / count

print("avrage:-",average)

# • Highest Salary Employee  

set1 = {x for x in my_set if x is not None}
print("max value :-",max(set1))

# Lowest Salary Employee 

set1 = {x for x in my_set if x is not None}
print("minimum value :-",min(set1))
