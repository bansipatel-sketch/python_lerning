# try:
#     a = 10
#     b = 0
#     c = a/ b
#     print("the result of divsion is",c)
# except Exception as e:
#     print(e)
#     print("this progrma is successfully run")



try:
    a = [10,20,30,40,50]
    print(a[4])
except Exception as e:
    print(e)
else:
    print("else block executed:-")
finally:
    print("Finally block is executed")

print("Array practical is successfullly Excuted")

