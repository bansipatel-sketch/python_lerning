#regex
# import re
# Namepattern = "^[a-zA-Z\\s]{1,50}$"
# name = input("please enter name:-")
# if re.match(Namepattern,name) != None:
#     print("Name is Valid")
# else:
#     print("Name is Note Valid")


# import re
# MobilePattern = "^[0-9]{10}$"
# Mobile = input("please enter obile No:-")
# if re.match(MobilePattern,Mobile) != None:
#     print("Mobile is Valid")
# else:
#     print("Mobile is Note Valid")

import re
MobilePattern = "^[0-9]{10}$"
Mobile = input("please enter Mobile No:-")


while re.match(MobilePattern,Mobile) == None:
   
    print("Mobile is Note Valid")
    Mobile = input("please Re-enter mobile No:-")

print("Mobile is Valid")