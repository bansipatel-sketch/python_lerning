
customerList =[]
CustomerName = int(input("How Many Cutomer You Want to Add?:-"))
print("====================================================================================")
for j in range(CustomerName):
    GrandTotal = 0
    shoppingList = []
    
    print("====================================================================================")
    Name = input("Please Enter Customer Name:-")
    print("====================================================================================")
    Product = int(input("How Many Products You Want to Add:-"))
    
    print("====================================================================================")
    for i in range(Product):
        print("================================================================================")
        print(f"{i+1}#.")
        print("================================================================================")
        ProductName = input("Please Enter product Name:-")
        ProductPrice = int(input("Please Enter Product Price:-"))
        ProcuctQty = int(input("Please Enter Product Qty:-"))
        Total = ProductPrice*ProcuctQty
    
        GrandTotal += Total
        Discount = GrandTotal / 10
        NetTotal = GrandTotal-Discount

        shoppingDict ={
            
            "productName" : ProductName,
            "Productprice":ProductPrice,
            "productQty":ProcuctQty,
            "Total":Total


        }
        shoppingList.append(shoppingDict)   

        customerData = {
             "name":Name,
             "Product":shoppingList,
             "GrandTotal":GrandTotal,
             "Discount":Discount,
             "NetTotal":NetTotal
        }

        customerList.append(customerData)

for customer in customerList:
    print("================================================================================")
    print("================================================================================")
    print("Customer Name:-",customer["name"])
    print("================================================================================")
    print("================================================================================")
    print("No\tName\tPrice\tQty\tTotal")
    print("================================================================================")
    count = 1
    for  singleCustomer in customer["Product"]:
            print(f"{count}",end="\t")
            for value in singleCustomer.values():
                print(f"{value}",end="\t")
            count += 1
            print("")
    print("=================================================================================")
    print("GrandTotal:-",customer["GrandTotal"])
    print("Discount:-",customer["Discount"])
    print("Net Total:-",customer["NetTotal"])
    print("Thakyou for Shooping.")