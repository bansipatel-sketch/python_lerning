employeeList = []
employee = int(input("How Many Employee You want to Add?:-"))
print("======================================================================================")
for i in range(employee):
    print("======================================================================================")
    EmployeeId = int(input("Please Enter Employee Id:-"))
    EmployeeName = input("Please Enter Employee Name:-" )
    EmployeeRole = input("please Enter Employee Role:-")
    Employeesalary = int(input("Please Enter Employee salary:-"))
    da = 0.5*Employeesalary
    hra = 0.1*Employeesalary
    medical = 0.04*Employeesalary
    gross = Employeesalary+da+hra+medical
    insurance = 0.7 *gross
    pf = 0.5 *gross
    ded =  insurance + pf
    netsalary = gross - ded
    print("======================================================================================")

    employeeDict = {
        "EmployeeId":EmployeeId,
        "EmployeeName":EmployeeName,
        "EmployeeRole":EmployeeRole,
        "EmployeeSalary":Employeesalary,
        "DA":da,
        "hra":hra,
        "medical":medical,
        "gross":gross,
        "insurance":insurance,
        "pf":pf,
        "ded":ded,
        "netsalary":netsalary


    }

    employeeList.append(employeeDict)
    
print("=======================================================================================================================================")
print("No\tEmpId\tName\tEmpRole\tB.salary\tDA\tHRA\tMEDIAL\tG.salary\tINSURANCE\tPF\tDeduction\tN.salary")
print("========================================================================================================================================")
count = 1
for singleEmployee in employeeList:
    print(f"{count}",end="\t")
    for value in singleEmployee.values():
        print(f"{value}",end="\t")
    count +=1
    print("")
print("=========================================================================================================================================")


