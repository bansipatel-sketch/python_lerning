# no =int (input("please Enter No:-"))

# file = open("Even.txt","w")
# fil= open("odd.txt","w")
# file.write("Even:-")
# for i in range(1,no,1):
#     if i % 2 == 0:
#        file.write(str(i))
   
        
# file.close()
# print("file write successfully")

# fil.write("odd:-")
# for i in range(1,no,1):
#     if i % 2 != 0:
#        fil.write(str(i))
   
        
# fil.close()
# print("file write successfully")




file = open("Even.txt","r")
line = file.read()
file.close()
print(line)
print("your file is successfully read:-")


fil = open("odd.txt","r")
lin = fil.read()
fil.close()
print(lin)
print("your file is successfully read:-")


