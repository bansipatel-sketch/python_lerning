file = open("BioData.txt","w")

name = input("please Enter YourName:-")
fathername = input("please Enter Your Father Name:-")
mobileno = input("please Enter your Mobile No:-")
Email = input("please Enter Your Email:-")
file.writelines(name)
file.writelines(fathername)
file.writelines(mobileno)
file.writelines(Email)

file.close()
print("your file is successfully read:-")


# file = open("BioData.txt","r")
# line = file.read()
# file.close()
# print(line)
# print("your file is successfully read:-")