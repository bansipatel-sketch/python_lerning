import re
from shopping import shopping
Namepattern = "^[a-zA-Z\\s]{1,50}$"
Name = input("please enter Name:-")
while re.match(Namepattern,Name) == None:
   
           print("productName is Note Valid")
           Name= input("please Re-enter product No:-")





No = int(input("How Many customer You Want to Add:-"))
garndtotal = 0

print("=========================================================================")
shoppingList = []
for i in range(No):
    print("================================================================================")
    print(f"{i+1}#.")
    print("================================================================================")
    s = shopping()
    s.ReadData()
    shoppingList.append(s)
    garndtotal += s.total
    Discount = garndtotal / 10
    NetTotal = garndtotal-Discount

print("=========================================================================")
print("Customer Name:-",Name)
print("=========================================================================")
print("No\tName\tPrice\tQty\tTotal")
print("=========================================================================")
count = 1
for singlecustomer in shoppingList:
   print(f"{count}",end="\t")
   singlecustomer.showData()
   count +=1

#    file.close()
#    print("file write successfully")


print("GrandTotal:-",garndtotal)
print("Discount:-",Discount)
print("NetTotal:-",NetTotal)
print("Thak you For shopping.")
