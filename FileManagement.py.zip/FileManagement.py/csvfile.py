import csv
f = open("Indian_Sample_Data.csv","r")

csvfilereader = csv.reader(f)
for line in csvfilereader:
    print(line[0],"\t",line[1],"\t",line[2],"\t",line[3])

f.close()