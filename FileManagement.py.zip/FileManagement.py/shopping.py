import re
class shopping:
    def __init__(self):
      
       self.productName = ""
       self.price = 0
       self.Qty = 0
       self.total = 0
      

       


    def ReadData(self):
        productpattern = "^[a-zA-Z\\s]{1,50}$"
        self.productName = input("please Enter Product Name:-")
        while re.match(productpattern,self.productName) == None:
   
           print("productName is Note Valid")
           self.productName = input("please Re-enter product No:-")
        
        self.price = int(input("Please Enter Price:-"))
        self.Qty = int(input("please Enter Qty:-"))
        self.total = self.price*self.Qty
       
        

    def showData(self):
        file = open("shopping.txt","w")
        # print(self.productName,"\t",self.price,"\t",self.Qty,"\t",self.total)
        file.write(str(self.productName))
        file.write("\t")
        file.write(str(self.price))
        file.write("\t")
        file.write(str(self.Qty))
        file.write("\t")
        file.write(str(self.total))
    
        file.close()


        file = open("shopping.txt","r")
        line = file.read()
        file.close()
        print(line)
       