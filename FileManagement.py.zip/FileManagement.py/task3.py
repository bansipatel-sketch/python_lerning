# print("Create Different Language File Like")
# print("Please Enter option from Below:-")
# print("1.For C programing")
# print("2.For C++ programing")
# print("3.For java programing")
# print("4.Python programing")

# file=open("Programming.txt","w")

# choice=int(input("Enter your choice:-"))
# File=input("Enter File name :-")

# Extension=""
# content=""

# match choice:
#     case 1:
#         extension = ".c"
#         content = "#include<stdio.h>\n#include<conio.h>\nvoid main()\n{\nclrscr();\ngetch();\n}"
        
#     case 2:
#       extension = ".cpp"
#       content = "#include<stdio.h>\n#include<conio.h>\nvoid main()\n{\nclrscr();\ngetch();\n}"
      
#     case 3:
#       extension = ".java"
#       content = "hello!java"
      
#     case 4:
#       extension = ".py"
#       content = "print('hello!python')"
      

# files=extension+content

# file.write(content)
# file.close()
# print("File successfully created.")



File = open("Programming.txt","r")
line = File.read()
File.close()
print(line)
print("file read successfully:-")