#File Write
# file = open("MyData.txt","w")
# file.write("hello pytho developer\n")
# file.write("My name is priyank patel")
# file.close()
# print("your file is created successfully.")


#file read
file = open("MyData.txt","r")
line = file.read()
file.close
print(line)
print("your file is created successfully.")