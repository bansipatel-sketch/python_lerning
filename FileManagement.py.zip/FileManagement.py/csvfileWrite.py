import csv
header = ["RollNo","Name","Mobile","Class"]
data1 = [1,"Bansi",2345678976,"BCA"]
data2 = [2,"Snehal",5478963525,"BCA"]

file = open("studentdata.csv","w")

writer = csv.writer(file)
writer.writerow(header)
writer.writerow(data1)
writer.writerow(data2)

file.close()


print("your student cvs file is sucessfully Created.")
