from studentcalss import student

#object = instant()
#class intialization
no = int(input("how many student you want to add:-"))
studentList = []
for i in range(no):
  s = student()
  s.ReadData()
  studentList.append(s)



print("=====================================================================")
print("RollNo\tName")
print("=====================================================================")
for singlestudent in studentList:
  singlestudent.showData()
