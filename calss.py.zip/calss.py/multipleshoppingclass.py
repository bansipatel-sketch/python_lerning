class shopping:
    def __init__(self):
      
       self.productName = ""
       self.price = 0
       self.Qty = 0
       self.total = 0
      

       


    def ReadData(self):
        self.productName = input("please Enter Product Name:-")
        self.price = int(input("Please Enter Price:-"))
        self.Qty = int(input("please Enter Qty:-"))
        self.total = self.price*self.Qty
       
        

    def showData(self):
        print(self.productName,"\t",self.price,"\t",self.Qty,"\t",self.total)