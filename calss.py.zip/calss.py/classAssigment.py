from classAssigmentClass import Member

print("Welcome to use sport Membership calculator")
customerno = int(input("HoW Many customer you Want to Add:-"))
memberList = []
print("==================================================================================================")
for i in range(customerno):
      print("=========================================================================")
      print(f"{i+1}#")
      print("=========================================================================")

      m = Member()
      m.readData()
      memberList.append(m)

 
print("=========================================================================")
print("No\tName\tMonth\tSpecialOffer\tCharge")
print("=========================================================================")
count = 1

for singlecustomer in memberList:
        print(count, end="\t")
        singlecustomer.showData()
        count += 1 

        
        
        


print("============================================================================")
maxcharge = memberList[0]
mincharge = memberList[0]
less = 0
Graterthan = 0
for i in memberList:

        
        if i.charge > maxcharge.charge:
              maxcharge =  i
        if i.charge < mincharge.charge:
            mincharge = i
        if i.Month < 6:
              less += 1
        else:
              Graterthan += 1


print("============================================================================")
print("the customer spending most is",maxcharge.name,"$",maxcharge.charge)  
print("the customer spending most is",mincharge.name,"$",mincharge.charge)  
print("============================================================================")

print("The number of member with > 6 month =",end=" ")
for i in range(Graterthan):
    print("x",end=" ")
print()
print("The number of member with < 6 month =",end=" ")
for i in range(less):
    print("x",end=" ")
print()


    