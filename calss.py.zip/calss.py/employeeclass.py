from employee import Employee

no = int(input("How Many you Want to Add:-"))
employeeList = []

print("==========================================================================")
for i in range(no):
     print("==========================================================================")
     print(f"{i+1}#.")
     print("==========================================================================")
     e = Employee()
     e.ReadData()
     employeeList.append(e)

print("==================================================================================================================")
print("No\tEmpId\tName\tEmpRole\tB.salary\tDA\tHRA\tMedical\tG.salary\tInsurance\tPF\tDeducation\tN.Salary")
print("==================================================================================================================")
count = 1
for singleempmoyee in employeeList:
     print(f"{count}",end="\t")
     singleempmoyee.showData()
     count +=1
