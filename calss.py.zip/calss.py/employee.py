class Employee:
    def __init__(self):
        self.Id = 0
        self.Name = ""
        self.employeerole = ""
        self.salary = 0
        self.DA = 0
        self.HRA = 0
        self.Medical = 0
        self.Gsalary = 0
        self.Insurance = 0
        self.pf = 0
        self.deducation = 0
        self.netsalary = 0

    def ReadData(self):
        self.Id = int(input("please Enter Id :-"))
        self.Name = input("please Enetr Employee Name:-")
        self.employeerole = input("please Enetr Employee Role:-")
        self.salary = int(input("please Enter Employee Basic Salary :-"))
        self.DA = 0.5*self.salary
        self.HRA = 0.1*self.salary
        self.Medical = 0.04*self.salary
        self.Gsalary = self.salary+self.DA+self.HRA+self.Medical
        self.Insurance = 0.7*self.Gsalary
        self.pf = 0.5*self.Gsalary
        self.deducation = self.Insurance + self.pf
        self.netsalary = self.Gsalary - self.deducation     

    def showData(self):
        print(self.Id,"\t",self.Name,"\t",self.employeerole,"\t",self.salary,"\t",self.DA,"\t",self.HRA,"\t",
              self.Medical,"\t",self.Gsalary,"\t",self.Insurance,"\t",self.pf,"\t",self.deducation,"\t",self.netsalary)
