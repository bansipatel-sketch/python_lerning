class Member:
    def __init__(self):
        self.name=""
        self.Month = 0
        self.specialoffer=""
        self.charge = 0


    def readData(self):
        self.name = input("please Customer Name:-")
        self.Month = int(input("Enter the number of month:-")) 
       
        while True:
      
            if self.Month <= 60:
                    print("Month:-",self.Month)
                    break
            else:
                    print("Invalid Month")
                    print("Re-Enter Month")


        if self.Month <= 6:
                self.charge = self.Month * 30.0
        elif self.Month <= 12:
                self.charge = self.Month*27.5
        else:
                self.charge = self.Month*25.0
            


        self.specialoffer = input("Enetr Yes or No to indicated a special offer:- ")   
        print("The membership of fee from",self.name ,"is" ,self.charge)
       

              
    

    def showData(self):
     print(self.name,"\t",self.Month,"\t",self.specialoffer,"\t",self.charge)
