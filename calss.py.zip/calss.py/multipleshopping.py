from multipleshoppingclass import shopping

customerName = int(input("How Many Customer You Want to Add:- "))
print("=========================================================================")

for i in range(customerName):

    shoppingList = []
    grandTotal = 0

    print("=========================================================================")
    Name = input("Please Enter Customer Name:- ")
    print("=========================================================================")

    No = int(input("How Many Product You Want to Add:- "))
    print("=========================================================================")

    for j in range(No):
        print("=========================================================================")
        print(f"{j+1}#")
        print("=========================================================================")

        s = shopping()
        s.ReadData()

        shoppingList.append(s)
        grandTotal += s.total

    Discount = grandTotal * 10 // 100
    NetTotal = grandTotal - Discount

    # -------- Customer Bill --------
    print("=========================================================================")
    print("Customer Name :", Name)
    print("=========================================================================")
    print("No\tName\tPrice\tQty\tTotal")
    print("=========================================================================")

    count = 1
    for singlecustomer in shoppingList:
        print(count, end="\t")
        singlecustomer.showData()
        count += 1

    print("=========================================================================")
    print("Grand Total =", grandTotal)
    print("Discount (10%) =", Discount)
    print("Net Total =", NetTotal)
    print("Thanks For Shopping")
    print("=========================================================================")