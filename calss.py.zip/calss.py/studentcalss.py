class student:
    #student constructor
    def __init__(self):
       self.RollNo = "0" #class property declaration
       self.Name =""

    def ReadData(self):
        self.RollNo = int(input("please enter number:-"))
        self.Name = input("please enter name:-")

    def showData(self):
        print(self.RollNo,"\t",self.Name)